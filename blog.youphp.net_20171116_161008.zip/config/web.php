<?php return array (
  'web_title' => 'Blog系统',
  'web_count' => '百度统计',
  'web_status' => '0',
  'seo_title' => '练手博客项目',
  'keywords' => '北京php培训,php视频教程,php培训,php基础视频,php实例视频,lamp视频教程',
  'description' => '一个简单的个人博客系统，只为laravel5.2练手',
  'copyright' => 'Design by Yarnell <a href="http://blog.youphp.net" target="_blank">http://blog.youphp.net</a>',
);