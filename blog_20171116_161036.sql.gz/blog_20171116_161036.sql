-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: blog
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blog_article`
--

DROP TABLE IF EXISTS `blog_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_article` (
  `art_id` int(11) NOT NULL AUTO_INCREMENT,
  `art_title` varchar(100) DEFAULT NULL,
  `art_tag` varchar(100) DEFAULT NULL,
  `art_description` varchar(255) DEFAULT NULL,
  `art_thumb` varchar(255) DEFAULT NULL,
  `file_upload` text,
  `art_content` text,
  `art_time` int(11) DEFAULT NULL,
  `art_editor` varchar(50) DEFAULT NULL,
  `art_view` int(11) DEFAULT NULL,
  `cate_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`art_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_article`
--

LOCK TABLES `blog_article` WRITE;
/*!40000 ALTER TABLE `blog_article` DISABLE KEYS */;
INSERT INTO `blog_article` VALUES (1,'上海楼市新政半月 成交腰斩','上海,楼市','来自克而瑞研究中心数据显示，上海3月21日~3月27日的一手房日均成交量为10.3万平方米，到了3月28日~4月3日的日均成交量急速下跌至4.5万平方米，环比下跌56%。','uploads/20160408101821971.jpg','uploads/20160408101821971.jpg','<p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">上海史上最严新政落地短短半月，市场正呈现另一番景象。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;来自克而瑞研究中心数据显示，上海3月21日~3月27日的一手房日均成交量为10.3万平方米，到了3月28日~4月3日的日均成交量急速下跌至4.5万平方米，环比下跌56%。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;记者近日走访多家中介，业务员普遍反映预期改变，来客量下滑5~6成，“市场风向变了，这是最明显的降温。”业务员陈颖（化名）说，这样的来客量对以后转化成交易也不是很有力。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;一、二手市场冷却</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;二手房网签数据的下滑可以看出市场冷却轨迹：上海中原地产数据显示，上海3月20日~3月24日的二手房网签套数为11220套，3月25日新政开始执行后，3月25日~3月31日网签8915套。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;新政前当月累计住宅成交量5.5万套，异常火爆。上海二手房指数办公室透露，“3·25”新政前，在改善性置换强劲推动下，中环以内中高端房大涨后的挤出效应，外围房源紧缺导致涨声一片，全市再现普涨格局。其中，改善客成交占比六成以上，一些首置刚需则畏于高房价退出市场。有业主连续跳价，有的不惜毁约唯恐低卖。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;而“3·25”新政后一周，成交萎缩二至四成，板块看房量大降三至八成，减量中非户籍看房客约占六成。新政后违约案例骤增，退房成潮或逾三成。截至2016年3月31日，全市二手住宅挂牌量为132248套，较上月上升7.5%。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;上海中原地产市场分析师卢文曦指出，一些全新入市的项目不排除会有低于市场预期的价格入市。对于有的新盘，周边的二手房价格不低，加上税费可能还高于新房，所以这些项目的价格相对会比较坚挺些。总的来说，房企定价会随行就市，价格的定制会简单理性。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;然而，上述克而瑞研究报告却指出，在过去一周热销楼盘中，仍然是房价上涨的项目更多。并且在上海的嘉定新城、松江泗泾等热点板块，标杆项目近一周备案房价较3月月均涨幅更是达到了4%。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;买家进退两难</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;值得一提的是，在3月25日新政实施当天网签而又不符合新政规定的购买者，陷入了两难境地：不甘心退房，因为等条件符合新政规定或许又要几年后，这些购房者出于对房价上涨的心理预期而不愿意退房；交易中心的流程已经没法往下走，如果不退房，目前购房者只有继续与中介、卖家各方僵持。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;而这当中牵涉多个一手楼盘，不确定是否退房的房源暂时无法统计，但按照3月25日一手房网签2495套、二手房网签2398套来测算，牵涉退房的数量规模不小。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;克而瑞研究中心分析师杨科伟分析认为，一线城市供不应求基本面不变，短期内房价下跌可能性不大，但受政策收紧影响，成交规模将有所收窄，并且在前期惯性消耗殆尽之后，一线城市年中或将出现新一轮的缩量；二线城市政策面依然趋宽，部分热点城市虽然开始出台房价调控，但力度相对有限，市场热度有望继续保持，而武汉、成都、合肥等近年城建快速发展、人口基数较大的单中心城市，市场规模更有进一步向上突破的可能。沪、深各类产品需求占比相对稳定，存量需求释放后成交才会真正下探。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 14px; white-space: normal; background-color: rgb(244, 244, 244);\">&nbsp;&nbsp;他指出，两到三个月后，待最热的这批“本地需求”释放完毕，本轮新政才会真正发力，届时上海、深圳面对的才是真正的结构性下跌。</p><p><br/></p>',1508250341,'yarnell',19,1),(2,'革命性的iPhone X发布！致敬乔布斯，没有比它更好的方式','iPhone X发布,致敬乔布斯','在 iPhone 诞生十周年之际，本次苹果的秋季发布会也移师到刚刚建成的乔布斯剧院进行。乔布斯给世界带来了无与伦比的 iPhone 手机，颠覆了我们此前对手机的认识；同时开创了新手机的时代，iPhone 也被高度评价为“重新定义了手机”。','uploads/cc11728b4710b912c94a7fd6c8fdfc039245220a.jpg','uploads/cc11728b4710b912c94a7fd6c8fdfc039245220a.jpg','<p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Heiti SC&quot;, &quot;Microsoft YaHei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">在 iPhone 诞生十周年之际，本次苹果的秋季发布会也移师到刚刚建成的乔布斯剧院进行。乔布斯给世界带来了无与伦比的 iPhone 手机，颠覆了我们此前对手机的认识；同时开创了新手机的时代，iPhone 也被高度评价为“重新定义了手机”。</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Heiti SC&quot;, &quot;Microsoft YaHei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">然而在这个值得纪念的时刻，十年之后发布的新 iPhone 们，又可以达到一个什么样的高度，是不是有足够的实力，可以和当初划时代的初代 iPhone 相提并论呢？相信大家心里都有自己的答案。</p><h2 style=\"margin: 0px 0px 15px; padding: 0px; font-size: 17px; color: rgb(51, 51, 51); line-height: 1.8; text-align: center; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Heiti SC&quot;, &quot;Microsoft YaHei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">iPhone 十周年的集大成者：iPhone X</h2><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Heiti SC&quot;, &quot;Microsoft YaHei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">就如此前一张又一张的渲染、曝光图所展示的那样，iPhone X 如期而至。作为 iPhone 十周年纪念的重磅产品，无论从命名还是设计，iPhone X 处处都展现出了它的特别之处。</p><p><span style=\"font-weight: 700; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Heiti SC&quot;, &quot;Microsoft YaHei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; background-color: rgb(255, 255, 255);\">iPhone X 的 X 是罗马字母 10 的意思，对应了 iPhone 十周年纪念版这个主题。</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Heiti SC&quot;, &quot;Microsoft YaHei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; background-color: rgb(255, 255, 255);\">这样的称呼并不陌生，苹果许多产品都曾经采用过这样的命名方式。同时作为一款纪念型号，iPhone X 应该是独立于普通 iPhone 之外的，它并不是 iPhone 7 或者 iPhone 8 的续作，而是独一无二的特殊产品。</span><span style=\"font-weight: 700; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Heiti SC&quot;, &quot;Microsoft YaHei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; background-color: rgb(255, 255, 255);\">iPhone X 的独特同时也表现在设计上。</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Heiti SC&quot;, &quot;Microsoft YaHei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; background-color: rgb(255, 255, 255);\">iPhone X 是苹果首款全面屏手机，同时也是苹果 iPhone 产品中设计最超前，最突出的一款。除了 iPhone X 之外，没有哪一款iPhone手机能够给人留下如此深刻的印象，不管他在消费者眼里是美还是丑。</span></p>',1508250831,'yarnell',12,4),(3,'还记得《倚天屠龙记》里的丁敏君吗?她现在长这样!','还记得《倚天屠龙记》里灭绝师太的弟子丁敏君吗？','还记得《倚天屠龙记》里灭绝师太的弟子丁敏君吗？','uploads/W020171017356982743671.jpg','uploads/W020171017356982743671.jpg','<p><span style=\"color: rgb(69, 69, 69); font-family: 宋体; text-align: -webkit-center;\">还记得《倚天屠龙记》里灭绝师太的弟子丁敏君吗？</span></p><p><span style=\"color: rgb(69, 69, 69); font-family: 宋体; text-align: -webkit-center;\">就是那个整天凶巴巴、拽到不行、还整天欺负周芷若的丁师姐呀。</span></p><p><span style=\"color: rgb(69, 69, 69); font-family: 宋体;\">　丁敏君的扮演者叫林静，1980年出生，毕业于北电表演系。这几年很火的家庭剧《妻子的谎言》和《爱人的谎言》里都有她哦~</span></p><p><span style=\"color: rgb(69, 69, 69); font-family: 宋体; text-align: -webkit-center;\">去年参演了《我在锡林郭勒等你》，她在里面饰演一个强势的女汉子。</span><img src=\"/ueditor/php/upload/image/20171017/1508251333958414.jpg\" title=\"1508251333958414.jpg\" alt=\"W020171017356982743671.jpg\"/></p><p><span style=\"color: rgb(69, 69, 69); font-family: 宋体; text-align: -webkit-center;\">最近刚播完的《上古情歌》里也有她哦，剧中她饰演了蝉雷氏一角~</span><img src=\"/ueditor/php/upload/image/20171017/1508251359635354.jpg\" title=\"1508251359635354.jpg\" alt=\"W020171017356982778234.jpg\"/></p><p><span style=\"color: rgb(69, 69, 69); font-family: 宋体; text-align: -webkit-center;\">林静今年36岁，然而自拍超级嫩的啊....</span><img src=\"/ueditor/php/upload/image/20171017/1508251386563165.jpg\" title=\"1508251386563165.jpg\" alt=\"W020171017356982806914.jpg\"/></p><p><span style=\"color: rgb(69, 69, 69); font-family: 宋体; text-align: -webkit-center;\">不愧是女演员，保养得非常好了。</span></p><p><span style=\"color: rgb(69, 69, 69); font-family: 宋体; text-align: -webkit-center;\"><img src=\"/ueditor/php/upload/image/20171017/1508251404862465.jpg\" title=\"1508251404862465.jpg\" alt=\"W020171017356982833772.jpg\"/></span></p><p><span style=\"color: rgb(69, 69, 69); font-family: 宋体; text-align: -webkit-center;\"><span style=\"color: rgb(69, 69, 69); font-family: 宋体; text-align: -webkit-center;\">杂志写真什么的超有范儿~</span></span></p><p><span style=\"color: rgb(69, 69, 69); font-family: 宋体; text-align: -webkit-center;\"><img src=\"/ueditor/php/upload/image/20171017/1508251441680541.jpg\" title=\"1508251441680541.jpg\" alt=\"W020171017356983024946.jpg\"/></span></p><p><span style=\"color: rgb(69, 69, 69); font-family: 宋体; text-align: -webkit-center;\"></span></p><p style=\"text-align:center;padding: 0px; border: 0px; line-height: 2; font-family: 宋体; font-size: 12pt; color: rgb(69, 69, 69); white-space: normal;\"><strong style=\"margin: 0px; padding: 0px; border: 0px;\">最后一句</strong></p><p style=\"padding: 0px; border: 0px; line-height: 2; font-family: 宋体; font-size: 12pt; color: rgb(69, 69, 69); white-space: normal;\">　　突然发现《倚天屠龙记》里的美女好多啊~</p><p><span style=\"color: rgb(69, 69, 69); font-family: 宋体; text-align: -webkit-center;\"><br/></span><br/></p>',1508251445,'yarnell',15,11),(4,'git教程','git,github,教程,版本库,版本管理','git是一个版本控制器，本教程介绍了一下基础命令和简单应用。','uploads/20171031224935802.jpg','phpstorm64.exe','<p>1.git安装：linux:<span style=\"white-space: pre;\"></span>sudo apt-get install git /sudo apt-get install git-core</p><p><br/></p><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Mac OS X:<span style=\"white-space:pre\"></span>appstore下载Xcode，集成了Git，运行Xcod，选择菜单“Xcode”-&gt;“Preferences”，在弹出窗口中找到“Downloads”，选择“Command Line Tools”，点“Install”就可以完成安装了。或者通过homebrew安装Git，参照http://brew.sh/</p><p><br/></p><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Windows:<span style=\"white-space:pre\"></span>安装集成软件msysgit是Windows版的Git，从https://git-for-windows.github.io下载（网速慢的同学请移步国内镜像），然后按默认选项安装即可。在开始菜单里找到“Git”-&gt;“Git Bash”，蹦出一个类似命令行窗口的东西，就说明Git安装成功！</p><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;设置git，命令行：$ git config --global user.name &quot;Your Name&quot;<span style=\"white-space:pre\"></span>$ git config --global user.email &quot;email@example.com&quot;</p><p><br/></p><p>2.创建版本库： 找一个空白的地方创建一个空目录（Windows目录名不包含中文）。</p><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 通过git init把这个目录变成Git可以管理的目录命令：</p><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $ git init Initialized empty Git repository in {$PATH[目录的系统路径]}/.git/</p><p><br/></p><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 注意：这个目录是Git来跟踪管理版本库的，没事千万不要手动修改这个目录里面的文件，不然改乱了，就把Git仓库给破坏了。</p><p><br/></p><p>3.把文件添加到版本库,utf8编码（windows不要用记事本要用编辑器）。&nbsp; 编写一个文件 readme.txt，添加命令为：</p><p><span style=\"white-space:pre\"></span>$ git add readme.txt&nbsp; //添加到仓库，可以多次添加</p><p><span style=\"white-space:pre\"></span>$ git commit -m &quot;wrote a readme file&quot;&nbsp; &nbsp;//提交到仓库并注释动作</p><p><br/></p><p>4.时光穿梭机。修改readme.txt文件。</p><p><span style=\"white-space:pre\"></span>①命令：$git status&nbsp;</p><p><span style=\"white-space:pre\"></span># On branch master</p><p><span style=\"white-space:pre\"></span># Changes not staged for commit:</p><p><span style=\"white-space:pre\"></span>#&nbsp; &nbsp;(use &quot;git add &lt;file&gt;...&quot; to update what will be committed)</p><p><span style=\"white-space:pre\"></span>#&nbsp; &nbsp;(use &quot;git checkout -- &lt;file&gt;...&quot; to discard changes in working directory)</p><p><span style=\"white-space:pre\"></span>#</p><p><span style=\"white-space:pre\"></span>#&nbsp; &nbsp; modified:&nbsp; &nbsp;readme.txt</p><p><span style=\"white-space:pre\"></span>#</p><p><span style=\"white-space:pre\"></span>no changes added to commit (use &quot;git add&quot; and/or &quot;git commit -a&quot;)</p><p><span style=\"white-space:pre\"></span>//命令可以让我们时刻掌握仓库当前的状态，上面的命令告诉我们，readme.txt被修改过了，但还没有准备提交的修改。</p><p><span style=\"white-space:pre\"></span>②命令：$git diff readme.txt&nbsp; &nbsp;//查看修改的内容</p><p><br/></p><p><span style=\"white-space:pre\"></span>③命令：$git log&nbsp; &nbsp;//显示从最近到最远的提交日志,可以试试加上--pretty=oneline参数</p><p><span style=\"white-space:pre\"></span>&nbsp; &nbsp;$git log --pretty=oneline&nbsp; &nbsp;--abbrev-commit</p><p><br/></p><p><span style=\"white-space:pre\"></span>④命令：$git reset --hard HEAD^ //HEAD当前版本, HEAD^上一个版本，HEAD^^上上一个版本，HEAD~n 上n个版本（n为整数）&nbsp;&nbsp;</p><p><span style=\"white-space:pre\"></span>&nbsp; &nbsp;$git reset --hard {commit_id} //commit_id 可以通过&nbsp; git log看到</p><p><br/></p><p><span style=\"white-space:pre\"></span>⑤命令：git reflog&nbsp; &nbsp;//重返未来，通过这个命令查看命令历史，以便确定回到那个版本</p><p>5.工作区、暂存区和分支区</p><p><span style=\"white-space:pre\"></span>git diff&nbsp; &nbsp; #是工作区(work dict)和暂存区(stage)的比较<span style=\"white-space:pre\"></span></p><p>&nbsp; &nbsp; git diff --cached&nbsp; &nbsp; #是暂存区(stage)和分支(master)的比较</p><p><br/></p><p>6.撤销修改</p><p><span style=\"white-space:pre\"></span>git checkout --readme.txt&nbsp; //意思就是，把readme.txt文件在工作区的修改全部撤销</p><p><span style=\"white-space:pre\"></span>git reset HEAD readme.txt&nbsp; //可以把暂存区的修改撤销掉（unstage）</p><p><br/></p><p>7.删除文件</p><p><span style=\"white-space:pre\"></span>命令：$git rm file&nbsp; &nbsp; $git commit -m &quot;remove file&quot;;&nbsp; //从版本库删除file文件</p><p><span style=\"white-space:pre\"></span>工作区删错了,想要恢复（就是用$rm filename误删了文件）&nbsp;</p><p><span style=\"white-space:pre\"></span>$git checkout --filename&nbsp; //用版本库里的版本替换工作区的版本，无论工作区是修改还是删除</p><p><br/></p><p>8.远程仓库：请自行注册GitHub账号。由于你的本地Git仓库和GitHub仓库之间的传输是通过SSH加密的。</p><p><span style=\"white-space:pre\"></span>第一步：创建SSH Key，<span style=\"white-space:pre\"></span>$ ssh-keygen -t rsa -C &quot;youremail@example.com&quot;</p><p><span style=\"white-space:pre\"></span>//你需要把邮件地址换成你自己的邮件地址，然后一路回车，使用默认值即可，由于这个Key也不是用于军事目的，所以也无需设置密码。如果一切顺利的话，可以在用户主目录里找到.ssh目录，里面有id_rsa和id_rsa.pub两个文件，这两个就是SSH Key的秘钥对，id_rsa是私钥，不能泄露出去</p><p><span style=\"white-space:pre\"></span>第二步：第2步：登陆GitHub，打开“Account settings”，“SSH Keys”页面：然后，点“Add SSH Key”，填上任意Title，在Key文本框里粘贴id_rsa.pub文件的内容</p><p><span style=\"white-space:pre\"></span>如果你不想让别人看到Git库，有两个办法，一个是交点保护费，让GitHub把公开的仓库变成私有的，这样别人就看不见了（不可读更不可写）。另一个办法是自己动手，搭一个Git服务器，因为是你自己的Git服务器，所以别人也是看不见的。这个方法我们后面会讲到的，相当简单，公司内部开发必备。</p><p><br/></p><p>9.添加远程库：在github建好一个git远程库。把远程库和本地库进行关联，可以进行推送</p><p><span style=\"white-space:pre\"></span>$ git remote add origin git@github.com:Tobe-No1/learngit.git&nbsp; // origin是远程库的名字</p><p><span style=\"white-space:pre\"></span>$ git push -u origin master&nbsp; //把本地库的内容推动到远程库 其实是把本地分支master推动到远程库，加上-u参数，Git不但会把本地的master分支内容推送的远程新的master分支，还会把本地的master分支和远程的master分支关联起来，在以后的推送或者拉取时就可以简化命令。</p><p><br/></p><p><span style=\"white-space:pre\"></span>注：第一次加上-u参数，之后可以不用加直接&nbsp; $ git push origin master</p><p><br/></p><p>10.从远程库克隆：</p><p><span style=\"white-space:pre\"></span>$ git clone git@github.com:Tobe-No1/gitskills.git</p><p><br/></p><p><span style=\"white-space:pre\"></span>注：要克隆一个仓库，首先必须知道仓库的地址，然后使用git clone命令克隆。</p><p><br/></p><p><span style=\"white-space:pre\"></span>Git支持多种协议，包括https，但通过ssh支持的原生git协议速度最快。</p><p><br/></p><p>11.Git分支</p><p><span style=\"white-space:pre\"></span>查看分支：git branch</p><p><br/></p><p><span style=\"white-space:pre\"></span>创建分支：git branch &lt;name&gt;</p><p><br/></p><p><span style=\"white-space:pre\"></span>切换分支：git checkout &lt;name&gt;</p><p><br/></p><p><span style=\"white-space:pre\"></span>创建+切换分支：git checkout -b &lt;name&gt;</p><p><br/></p><p><span style=\"white-space:pre\"></span>合并某分支到当前分支：git merge &lt;name&gt;</p><p><br/></p><p><span style=\"white-space:pre\"></span>删除分支：git branch -d &lt;name&gt;</p><p><br/></p><p>12.Bug分支：场景：当你接到一个修复一个代号101的bug的任务时，很自然地，你想创建一个分支issue-101来修复它，但是，等等，当前正在dev上进行的工作还没有提交，并不是你不想提交，而是工作只进行到一半，还没法提交，预计完成还需1天时间。但是，必须在两个小时内修复该bug，怎么办？</p><p>幸好，Git还提供了一个stash功能，可以把当前工作现场“储藏”起来，等以后恢复现场后继续工作。现在，用git status查看工作区，就是干净的（除非有没有被Git管理的文件），因此可以放心地创建分支来修复bug。</p><p><br/></p>',1508720460,'yarnell',NULL,4);
/*!40000 ALTER TABLE `blog_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_category`
--

DROP TABLE IF EXISTS `blog_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_category` (
  `cate_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '分类主键',
  `cate_name` varchar(50) DEFAULT NULL COMMENT '分类名称',
  `cate_title` varchar(255) DEFAULT NULL COMMENT '分类说明',
  `cate_keywords` varchar(255) DEFAULT NULL COMMENT '关键词',
  `cate_description` varchar(255) DEFAULT NULL COMMENT '描述',
  `cate_view` int(10) DEFAULT NULL COMMENT '查看次数',
  `cate_order` tinyint(4) DEFAULT NULL COMMENT '排序',
  `cate_pid` int(11) DEFAULT NULL COMMENT '父级id',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_category`
--

LOCK TABLES `blog_category` WRITE;
/*!40000 ALTER TABLE `blog_category` DISABLE KEYS */;
INSERT INTO `blog_category` VALUES (1,'新闻','搜集国内外最热门的新闻','','',NULL,1,0),(2,'体育','发展体育事业，增强人民体质','体育新闻','发展体育事业，增强人民体质',NULL,2,0),(3,'娱乐','人人都有自己的娱乐圈',NULL,NULL,NULL,3,0),(4,'热点新闻','热门新闻每日排行_新闻中心_新浪网',NULL,NULL,NULL,1,1),(5,'军事新闻','军事频道_最多军迷首选的军事门户_新浪网',NULL,NULL,NULL,1,1),(6,'体育彩票','国家体育总局体育彩票管理中心官方网站',NULL,NULL,NULL,2,2),(7,'乐视体育','乐视体育-让每个人更好的参与体育',NULL,NULL,NULL,2,2),(8,'腾讯体育','腾讯体育_腾讯网',NULL,NULL,NULL,2,2),(10,'娱乐风向标','搜集最热门的娱乐动向','娱乐，娱乐圈','搜集最热门的娱乐动向',NULL,3,3),(11,'娱乐动向','娱乐动向娱乐动向','娱乐动向','娱乐动向娱乐动向娱乐动向娱乐动向',NULL,3,3);
/*!40000 ALTER TABLE `blog_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_config`
--

DROP TABLE IF EXISTS `blog_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_config` (
  `conf_id` int(11) NOT NULL AUTO_INCREMENT,
  `conf_title` varchar(50) DEFAULT NULL,
  `conf_name` varchar(50) DEFAULT NULL,
  `conf_content` text,
  `conf_order` int(11) DEFAULT NULL,
  `conf_tips` varchar(255) DEFAULT NULL,
  `field_type` varchar(50) DEFAULT NULL,
  `field_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`conf_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_config`
--

LOCK TABLES `blog_config` WRITE;
/*!40000 ALTER TABLE `blog_config` DISABLE KEYS */;
INSERT INTO `blog_config` VALUES (1,'网站标题','web_title','个人博客系统',1,'网站大众化标题','input',NULL),(2,'统计代码','web_count','abs',2,'网站访问量统计','textarea',''),(3,'网站状态','web_status','1',3,'显示网站状态','radio','1|开启,0|关闭');
/*!40000 ALTER TABLE `blog_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_links`
--

DROP TABLE IF EXISTS `blog_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_links` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `link_name` varchar(50) DEFAULT NULL,
  `link_title` varchar(255) DEFAULT NULL,
  `link_url` varchar(50) DEFAULT NULL,
  `link_order` int(11) NOT NULL,
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_links`
--

LOCK TABLES `blog_links` WRITE;
/*!40000 ALTER TABLE `blog_links` DISABLE KEYS */;
INSERT INTO `blog_links` VALUES (1,'我的博客','laravel5.2学习','http://blog.youphp.net',1),(2,'抚州淘','我的购物网站','http://fuzhoutao.com',2);
/*!40000 ALTER TABLE `blog_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_navs`
--

DROP TABLE IF EXISTS `blog_navs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_navs` (
  `nav_id` int(11) NOT NULL AUTO_INCREMENT,
  `nav_name` varchar(50) NOT NULL,
  `nav_alias` varchar(50) NOT NULL,
  `nav_url` varchar(255) NOT NULL,
  `nav_order` int(11) NOT NULL,
  PRIMARY KEY (`nav_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_navs`
--

LOCK TABLES `blog_navs` WRITE;
/*!40000 ALTER TABLE `blog_navs` DISABLE KEYS */;
INSERT INTO `blog_navs` VALUES (1,'新闻','news','http://blog.youphp.net',0),(2,'抚州淘','fuzhoutao','http://fuzhoutao.com',0),(3,'个人博客','blog','http://youyongbiao.com',3);
/*!40000 ALTER TABLE `blog_navs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_user`
--

DROP TABLE IF EXISTS `blog_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) DEFAULT NULL,
  `user_pass` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_user`
--

LOCK TABLES `blog_user` WRITE;
/*!40000 ALTER TABLE `blog_user` DISABLE KEYS */;
INSERT INTO `blog_user` VALUES (1,'admin','eyJpdiI6Im5jZ3FJOEFGUm1wUkg1T0xTajlCamc9PSIsInZhbHVlIjoiTWxJY2x4cmZKa1VPZnN3Y3pMYzNhZz09IiwibWFjIjoiNDcxMzUyNzIyZWE1MGUxNDFhYzViNTU5NDFmYjVhZjcxMDdmZTVhMWU2NTNiOGViOTY3MTViMThiMWZmY2Q0NyJ9');
/*!40000 ALTER TABLE `blog_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-16 16:10:36
